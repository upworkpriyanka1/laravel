<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*****************************
 * Model Class 
 *
 * ****************************/
class Welcome_mdl extends CI_Model {

        function __construct()
        {
            parent::__construct();

        }
/**********************
* Allways comment function
* access public
* @ params
* return 
*********************************/
    function test(){
        return "foo";
    }

}