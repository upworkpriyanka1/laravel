<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct() {
	   parent::__construct();


	/* load library & model with aliases, config and language */
			$this->load->library('Welcome_lib',NULL, 'welcome_lib');
			$this->load->model('Welcome_mdl','welcome_mdl');
			$this->lang->load('welcome');
			$this->config->load('welcome_menu', true );
			$this->menu    			= $this->config->item('welcome_menu');

			if (!isset($this->uri->segments[1])){ 
				redirect(base_url("welcome"));
			}
				
	}
/**********************
* View Dashboard Home
* access public
* @params
* return view
*********************************/
	public function index(){
		$data['meta_description']='';
		$data['menu']= $this->menu;
		$data['user'] = 'Test User';
		$data['page']='dashboard'; //page view to load
		$data['css'] 	= array();
		$data['js'] 	= array();
        $data['js_views'] 	= array();
		$data['title'] 	= page_title_hlp(); //see site_helper

		$data['page']		= 'dashboard/index';
		$this->load->view('index',$data);
	}

/**********************
* view Patients
* access public
* @params
* return view
*********************************/
	public function patients(){
		$data['meta_description']='';
		$data['menu']= $this->menu;
		$data['user'] = 'Test User';
		$data['title'] 	= page_title_hlp(); //see site_helper
        if (isset($this->uri->segments[3])){ //do patients actions
            $method = "patients_".str_replace('-', '_', $this->uri->segments[3]);
            if (method_exists($this, $method)){
                $this->{$method}($data);
                return true;
            }else{
                redirect(base_url($this->uri->segments[1]."/".$this->uri->segments[2]));
            }
        }
		$data['css'] 	= array('lib/vendors/datatables/datatables.min.css');
        $data['js_views'] 	= array('js/datatables');
		$data['title'] 	= page_title_hlp(); //see site_helper
		$data['page']		='patients/view';
		$this->load->view('index',$data);

	}
	
	
/**********************
* Add Patient
* access public
* @params
* return view
*********************************/
	public function patients_add(){
		if (isset($_POST['ajax'])){
			//do the necessary here 
			//if respmse numeric == sucess
			echo "1";
			return true;
		}
		
		$data['meta_description']='';
		$data['menu']= $this->menu;
		$data['user'] = 'Test User';
		$data['page']='dashboard'; //page view to load
		$data['js']     = array('lib/vendors/mask/jquery.mask.js','lib/js/patients-validator.js');
		$data['title'] 	= page_title_hlp(); //see site_helper
		$data['page']		='patients/add';
		$this->load->view('index',$data);

	}	
	
/**********************
* Edit Patient
* access public
* @params
* return view
*********************************/
	public function patients_edit(){
		if (isset($_POST['ajax'])){
			//do the necessary here 
			//if respmse numeric == sucess
			echo "Error msg here";
			return true;
		}
		
		$data['meta_description']='';
		$data['menu']= $this->menu;
		$data['user'] = 'Test User';
		$data['page']='dashboard'; //page view to load
		$data['js']     = array('lib/vendors/mask/jquery.mask.js','lib/js/patients-validator.js');
		$data['title'] 	= page_title_hlp(); //see site_helper
		$data['page']		='patients/edit';
		$this->load->view('index',$data);

	}	

}
