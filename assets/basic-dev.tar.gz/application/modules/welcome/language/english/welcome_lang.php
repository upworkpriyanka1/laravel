<?php 
$lang['welcome']        = "Welcome";
$lang['patients']       = "Patients";
$lang['patients-view']  = "View patients";
$lang['patients-add']   = "Add Patient";
$lang['patients-edit']  = "Edit Patient";
