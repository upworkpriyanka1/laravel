<div id="sidebar-menu" class="main_menu_side hidden-print main_menu mysidebar-menu">
    <div class="menu_section">
        <ul class="nav side-menu">

            <?php
            //make sure $segment and $view is defined
            foreach ($menu as $key => $value):
                    if (is_array($value)): //is value is array, it means it is Menu Item
                        //sent active menu

                    ?>
                    <!-- SIDEBAR MENU -->
                        <li><a><i class="<?= $menu[$key]['icon'];?>"></i> <?php echo lang($menu[$key]['title']);?> <span class="fa fa-chevron-down"></span></a>

                        <ul class="nav child_menu">
                    <?php
                        if (is_array($menu[$key])): //if $menu[$key] is arry, it means it is menu link
                            foreach ($menu[$key] as $key => $link):
                                if (is_array($link)): //if $link, ie  $key value is array

                    ?>
                    <!-- SIDEBAR MENU LINK -->
                            <li>
                                <a href="<?php echo base_url().$this->uri->segment('1').$link['href'];?>">
                                    <?php echo lang($link['title']);?>
                                </a>
                            </li>
                    <!-- END SIDEBAR MENU LINK -->
                            <?php
                                endif; //end if $link is array
                            endforeach;//end $menu[$key] foreach
                            ?>
                    </ul>
                </li>
                <!-- END SIDEBAR MENU -->
                <?php
                        endif; //end if $link is array
                    endif;//end if $value is array
                endforeach;//end $menu foreach
                ?>

        </ul>
    </div>
</div>