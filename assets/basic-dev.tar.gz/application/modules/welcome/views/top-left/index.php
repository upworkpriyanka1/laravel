<div class="navbar nav_title" style="border: 0;">
    <a href="<?= $this->uri->segments[1];?>" class="site_title user-profile">
        <img src="assets/avatar/avatar.png" alt="test">
        <span class="site_title_span">test</span>
    </a>
</div>