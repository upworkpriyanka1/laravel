<div class="top_nav navbar-fixed-top">
    <div class="nav_menu">
        <nav>
            <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
            </div>
                <!-- title -->
            <span class="page-title">
                <div class="title_left">
                    <h3><?= $title;?></h3>
                </div>
            </span>
                <!-- ./title -->


        </nav>
    </div><!-- ./nav_menu -->
</div>