<!-- BEGIN FORM-->

<form action="<?php echo current_url();?>" method="post" id="add-form" class="form-horizontal">
     <div class="x_panel">
    <div class="row">
            <div class="col-md-12">
Put the form here
</div>
</div>
</div>
</form>