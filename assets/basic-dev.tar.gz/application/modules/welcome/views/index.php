<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= lang($this->uri->segments[1]);?></title>
    <base href="/" /> <!-- THIS IS IMPORTANT -->
    <!-- Bootstrap Core CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-pdapHxIh7EYuwy6K7iE41uXVxGCXY0sAjBzaElYGJUrzwodck3Lx6IE2lA0rFREo" crossorigin="anonymous">
        <link href="lib/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Custom Theme Style -->
        <link href="lib/css/admin.css" rel="stylesheet">
    <!-- jQuery UI Style -->
        <link href="lib/vendors/jquery-ui/jquery-ui.min.css" rel="stylesheet">
    <!-- PNotify -->
        <link href="lib/vendors/pnotify/dist/pnotify.css" rel="stylesheet">
        <link href="lib/vendors/pnotify/dist/pnotify.buttons.css" rel="stylesheet">
        <link href="lib/vendors/pnotify/dist/pnotify.nonblock.css" rel="stylesheet">
    <!-- iCheck -->
        <link href="lib/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Switchery -->
        <link href="lib/vendors/switchery/switchery.min.css" rel="stylesheet">
    <!-- xEditable -->
        <link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
    <?php
        isset($css) ? load_css($css) : '';
    ?>



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <!-- Standard Favicon -->
         <link rel="icon" type="image/x-icon" href="assets/favicon/favicon.ico" />
    <!-- For iPhone 4 Retina display: -->
          <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/favicon/apple-touch-icon-114x114-precomposed.png">
    <!-- For iPad: -->
          <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/favicon/apple-touch-icon-72x72-precomposed.png">
    <!-- For iPhone: -->
          <link rel="apple-touch-icon-precomposed" href="assets/favicon/apple-touch-icon-57x57-precomposed.png">
 </head>

 <body class="nav-md">
    <div class="container body">
        <div class="main_container">
<!-- left column -->
            <div class="col-md-3 left_col  menu_fixed">
                <div class="left_col scroll-view">
    <!-- Top left -->
        <?php  $this->load->view('top-left/index');?>
    <!-- ./Top left -->
            <div class="clearfix"></div>
    <!-- sidebar menu -->
        <?php  $this->load->view('sidebar/index');?>
    <!-- /sidebar menu -->

    <!-- menu footer buttons -->

    <!-- /menu footer buttons -->
                </div><!-- ./left_col scroll-view -->
            </div>
<!-- ./left column -->

<!-- top navigation -->
    <?php  $this->load->view('top-navigation/index');?>
<!-- /top navigation -->

<!-- page content -->
            <div class="right_col" role="main">
                <div style="margin-top:55px" class="">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">

                                <?php
                                if (isset($page)){
                                    $this->load->view($page);
                                }
                                ?>
                            
                        </div><!-- ./col -->
                    </div><!-- ./row -->
                </div><!-- ./class"" -->
            </div>
<!-- /page content -->

        <!-- footer content -->
        <footer>
            <div class="pull-right">
                Xntral
            </div>
            <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
    </div><!-- ./"main_container -->
</div><!-- ./container body -->
    <!-- jQuery -->
        <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
    <!-- Bootstrap Core JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js" integrity="sha384-pPttEvTHTuUJ9L2kCoMnNqCRcaMPMVMsWVO+RLaaaYDmfSP5//dP6eKRusbPcqhZ" crossorigin="anonymous"></script>
    <!-- jQuery UI -->
        <script src="lib/vendors/jquery-ui/jquery-ui.min.js"></script>
    <!-- Fontawesome-->
        <script src="//use.fontawesome.com/624c716761.js"></script>

    <!-- NProgress -->
        <script src="lib/vendors/nprogress/nprogress.js"></script>
    <!-- validator -->
        <script src="lib/vendors/jquery-validation/js/jquery.validate.min.js"></script>
        <script src="lib/vendors/jquery-validation/js/additional-methods.min.js"></script>
        <script src="lib/vendors/jquery-validation/js/localization/messages_en.js"></script>
    <!-- PNotify -->
       <script src="lib/vendors/pnotify/dist/pnotify.js"></script>
       <script src="lib/vendors/pnotify/dist/pnotify.buttons.js"></script>
       <script src="lib/vendors/pnotify/dist/pnotify.nonblock.js"></script>

    <!-- BootBox -->
        <script src="lib/vendors/bootbox/bootbox.min.js"></script>

    <!-- xEditable -->
        <script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/js/bootstrap-editable.min.js"></script>
    <!-- jQuery_cookie -->
        <script src="lib/vendors/jquery_cookie/jquery_cookie.js"></script>
    <!-- Custom  Scripts -->
    <script src="lib/js/admin/admin.js"></script>
    <?php
        isset($js) ? load_js($js) : '';
    ?>

    <script>
        var success         = '<?= lang('success-ttl');?>';
        var error           = '<?= lang('error-ttl');?>';
        var recordCreated   = '<?= lang('record-created');?>';
        var recordSaved     = '<?= lang('record-saved');?>';
        var errorGeneral    = '<?= lang('error-general');?>';
        var ajaxError       = '<?= lang('ajax-error');?>';
        var LngConfirm      = '<?= lang('delete-confirm');?>';
        var LngIso          = '<?= $this->config->item('lng_code');?>';
    </script>
        <?php
            isset($js_views) ? load_js_views($js_views) : '';
        ?>
</body>
</html>