<!-- BEGIN FORM-->

<form action="<?php echo current_url();?>" method="post" id="edit-form" class="form-horizontal">
     <div class="x_panel">
    <div class="row">
            <div class="col-md-12">
                <!-- SUBMIT BTN -->
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <button type="submit" id="BtnSave" data-action="add" class="btn btn-primary"><?php echo lang('submit');?></button>
                        </div>
                    </div>
</div>
</div>
</div>
</form>