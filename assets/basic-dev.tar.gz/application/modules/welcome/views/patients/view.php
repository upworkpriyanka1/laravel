<!-- BEGIN-->

     <div class="x_panel">
    <div class="row">
            <div class="col-md-12">
Put the patients datatable here.
<p>Edit button should be here as well, next to each record.<br><a href='/welcome/patients/edit'>Edit Patient Example Link</a></p>
</div>
</div>
</div>
