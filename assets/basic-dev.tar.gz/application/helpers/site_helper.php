<?php
/*******************
 * Load CSS files
 * @params array
 * access public
 * @return CSS link
 * @author Naz
*****************************************************/
if (!function_exists('load_css')){
    function load_css($css_array=''){
        $CI =& get_instance();
        if (is_array($css_array)) {
            echo "<!-- Page specific CSS -->\r\n\t";
            foreach ($css_array as $value) {
                echo "<link href='".$value."' rel='stylesheet'>\r\n\t";
            }
		}

    }
}


/*******************
 * Load js files
 * @params array
 * access public
 * @return js javascript link
 * @author Naz
*****************************************************/
if (!function_exists('load_js')){
    function load_js($js_array=''){
        $CI =& get_instance();
        if (is_array($js_array)) {
            echo "<!-- Page specific JS -->\r\n\t";
            foreach ($js_array as $value) {
                echo "<script src='".$value."'></script>\r\n\t";
            }
		}

    }
}

/*******************
 * Load js php view files (<script></script>)
 * @params array
 * access public
 * @return js scrip
 * @author Naz
*****************************************************/
if (!function_exists('load_js_views')){
    function load_js_views($js_array=''){
        $CI =& get_instance();
        if (is_array($js_array)) {
            echo "<!-- Page specific inline javascript -->\r\n\t";
            foreach ($js_array as $value) {
                $CI->load->view($value).">\r\n\t";
            }
		}

    }
}




/*******************
 * Set page title
 * @params uri->segments[2] uri->segments[3]
*****************************************************/
if (!function_exists('page_title_hlp')){
    function page_title_hlp(){
        $CI =& get_instance();
    if (!isset($CI->uri->segments[2])):
        $url  ="<ol class='breadcrumb'>";
        $url .="<li><a href='".current_url()."'>".lang($CI->uri->segments[1])."</a></li>";
        $url .="</ol>";
        return $url;
    endif;
        $url  ="<ol class='breadcrumb'>";
        $url .=(isset($CI->uri->segments[3])) ? "<li><a href='".$CI->uri->segments[1]."/".$CI->uri->segments[2]."'>".lang($CI->uri->segments[2])."</a></li><li><a href='".current_url()."'>".lang($CI->uri->segments[3])."</a></li>" : "<li><a href='".current_url()."'>".lang($CI->uri->segments[2])."</a></li>";
        $url .="</ol>";
        return $url;



    }
}

